// #include<stdio.h>
// int main()
// {
//   int x;
//   printf("Enter a number:");
//   scanf("%d",&x);

//   if(x<0)
//     printf("The absolute value of %d is %d:",x,-x);
//   if(x>0)
//     printf("The absolute value of %d is %d:",x,x);

//   return 0;
// }