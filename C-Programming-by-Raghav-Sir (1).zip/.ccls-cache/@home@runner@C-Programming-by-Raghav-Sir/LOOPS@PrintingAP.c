// //To print AP: 4,7,10,.......upto n terms.
// #include<stdio.h>
// int main()
// {
//   int n;
//   printf("Enter the number:");
//   scanf("%d",&n);
//   for(int i=4;i<=3*n+1;i=i+3){

//     printf("%d ",i);

//   }
//   return 0;
// }



//AP:4,7,10,......
// #include<stdio.h>
// int main()
// {
//   int n;
//   int a=4;
//   int d=3;
//   printf("Enter the number:");
//   scanf("%d",&n);
//   for(int i=1;i<=n;i++){

//     printf("%d ",a);
//     a+=d;

//   }
//   return 0;
// }