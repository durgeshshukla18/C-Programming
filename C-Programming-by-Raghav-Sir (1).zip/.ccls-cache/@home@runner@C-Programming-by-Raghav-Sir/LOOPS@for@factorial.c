// #include<stdio.h>
// int main()
// {
//   int n;
//   printf("Enter the number : ");
//   scanf("%d",&n);
//   int num=1;
//   for(int i=2;i<=n;i++){
//   num=num*i;
//     }
//   printf("The factorial of %d is %d",n,num);
// }