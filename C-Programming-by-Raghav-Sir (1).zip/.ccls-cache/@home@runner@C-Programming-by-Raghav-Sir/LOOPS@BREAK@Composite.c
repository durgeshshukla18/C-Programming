// #include<stdio.h>
// int main()
// {
//   int n;
//   printf("Enter the number:");
//   scanf("%d",&n);

//   int check=0;//0 means prime
//   for(int i=2;i<=n-1;i++){
//     if(n%i==0){// i is a factor of n
//       printf("%d is a composite number.\n",n);
//       check=1;
//       break;
//     }
//   }
//   if(check==0){
//     printf("Prime\n");
//   }
//   else
//     printf("Composite\n");
  
  
  
//   return 0;

// }