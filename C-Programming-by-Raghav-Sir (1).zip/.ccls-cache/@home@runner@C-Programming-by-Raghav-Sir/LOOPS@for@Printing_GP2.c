// #include<stdio.h>
// int main()
// {
//   int a,r,n;
//   printf("Enter the first term of G.P. series: ");
//   scanf("%d",&a);
//   printf("Enter the common ratio of GP: ");
//   scanf("%d",&r);
//   printf("Enter the number of terms of GP: ");
//   scanf("%d",&n);
//   printf("GP is:");
//   for(int i=1;i<=n;i++){
//     printf("%d ",a);
//     a=a*r;
//   }
    
// } 