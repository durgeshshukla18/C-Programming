// #include<stdio.h>
// int main()
// {
//   int a,d,n;
//   printf("Enter the first term: ");
//   scanf("%d",&a);
//   printf("Enter the common difference:");
//   scanf("%d",&d);
//   printf("Enter the number of terms:");
//   scanf("%d",&n);
//   printf("AP is:");
//   for(int i=a;i>=0;i-=d){
//     printf("%d",i);
//   }
//   return 0;
// }