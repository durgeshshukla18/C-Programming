// //GP: 1,2,4,.....
// #include<stdio.h>
// int main()
// {
//   int n;
  
//   printf("Enter the number:");
//   scanf("%d",&n);
//   int a=1;
//   for(int i=1;i<=n;i++){

//     printf("%d ",a);
//     a=a*2;

//   }
//   return 0;
// }


// #include<stdio.h>
// int main()
// {
//   int n;
//   int a=1;
//   int r=2;
//   printf("Enter the number:");
//   scanf("%d",&n);
//   for(int i=1;i<=n;i++){

//     printf("%d ",a);
//     a*=r;

//   }
//   return 0;
// }


