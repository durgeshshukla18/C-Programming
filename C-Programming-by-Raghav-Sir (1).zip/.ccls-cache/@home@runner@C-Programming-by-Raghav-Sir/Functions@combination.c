////METHOD-1:-

// #include<stdio.h>
// int factorial(int x){
//   int f=1;
//   for(int i=2;i<=x;i++)
//     f=f*i;
//   return f;
// }
// int main()
// {
//   int n,r,nCr;
//   printf("Enter the n:");
//   scanf("%d",&n);
//   printf("Enter the r:");
//   scanf("%d",&r);
//   int nfact=factorial(n);
//   int rfact=factorial(r);
//   int n_rfact=factorial(n-r);
//   nCr=factorial(n)/(factorial(r)*factorial(n-r));
//   printf("The value of nCr is %d",nCr);
//   return 0;
// }



// //METHOD-2:-


// #include<stdio.h>
// int factorial(int x){
//   int f=1;
//   for(int i=2;i<=x;i++)
//     f=f*i;
//   return f;
// }
// int combination(int n,int r){
//   int nCr=factorial(n)/(factorial(r)*factorial(n-r));
//   return nCr;
// }
// int main()
// {
//   int n,r;
//   printf("Enter the n:");
//   scanf("%d",&n);
//   printf("Enter the r:");
//   scanf("%d",&r);
//   int nCr=combination(n,r);
//   printf("The value of nCr is %d",nCr);
//   return 0;
// }