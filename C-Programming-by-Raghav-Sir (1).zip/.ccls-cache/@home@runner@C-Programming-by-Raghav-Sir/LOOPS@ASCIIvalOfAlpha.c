// #include<stdio.h>
// int main()
// {
//   for(int i=65;i<=90;i++){
//     printf("%d %c\n",i,i);
//   }
//   return 0;
// }