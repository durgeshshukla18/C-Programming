 // #include<stdio.h>
// int main()
// {
//   for(int i=19;i<=190;i=i+19){

//     printf("%d ",i);
    
//   }
//   return 0;
// }


// #include<stdio.h>
// int main()
// {
//   for(int i=1;i<=10;i++){

//     printf("%d ",i*19);

//   }
//   return 0;
// }