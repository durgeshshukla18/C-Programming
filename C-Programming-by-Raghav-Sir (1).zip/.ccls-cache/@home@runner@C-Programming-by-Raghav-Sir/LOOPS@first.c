// #include<stdio.h>
// int main()
// {
//   for(int i=1;i<=7;i+=1){
//     printf("PWIOI");
//   }
// }