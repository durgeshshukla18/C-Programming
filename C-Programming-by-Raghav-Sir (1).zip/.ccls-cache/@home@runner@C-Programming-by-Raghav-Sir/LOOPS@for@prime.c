//  #include <stdio.h>
// int main()
// {
//   int n;
//   printf("Enter the number:");
//   scanf("%d",&n);
//   int a=0;
//   for(int i=2;i<=n/2;i++){
//     if(n%i==0){
//       a=1;
//         break;
//     }
//   }
//     if(a==0){
//       printf("%d is a Prime number.",n);
//     }
//    else{
//        printf("%d is a Composite Number",n);
//   }
//   return 0;
//   }