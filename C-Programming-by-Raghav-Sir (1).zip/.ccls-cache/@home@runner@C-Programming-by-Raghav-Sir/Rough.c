// #include<stdio.h>
// //  int main()
// //  {
// //    int x,y,z;
// //    printf("Enter the x:");
// //    scanf("%d",&x);
// //    printf("Enter the y:");
// //    scanf("%d",&y);
// //    printf("Enter the z:");
// //    scanf("%d",&z);

// //    if(x>y){
// //      if(x>z) printf("Greatest number is: %d",x);
// //      else {
// //        printf("Greatest number is: %d",z);
// //      }
// //    }
// //    else {
// //      if(y>z) printf("Greatest number is:%d",y);
// //      else {
// //        printf("Greatest number is:%d",z);
// //      }
// //    }
// //    return 0;
// //  }