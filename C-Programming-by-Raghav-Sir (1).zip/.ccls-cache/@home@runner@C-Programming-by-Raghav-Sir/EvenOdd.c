// #include<stdio.h>
// int main()
// {
//   int x;
//   printf("Enter a number:");
//   scanf("%d",&x);

//   if(x%2==0)
//     printf("Even number");
//   if(x%2==1)
//     printf("Odd number");

//   return 0;
// // }