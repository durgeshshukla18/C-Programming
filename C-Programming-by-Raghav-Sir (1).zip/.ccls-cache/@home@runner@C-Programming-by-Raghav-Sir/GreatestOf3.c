// #include<stdio.h>
//  int main()
//  {
//    int x,y,z;
//    printf("Enter the x:");
//    scanf("%d",&x);
//    printf("Enter the y:");
//    scanf("%d",&y);
//    printf("Enter the z:");
//    scanf("%d",&z);

//    if(x>y && x>z)
//      printf("%d is greatest number",x);
//    if(y>z && y>x)
//      printf("%d is greatest number",y);
//    if(z>x && z>y)
//      printf("%d is greatest number",z);
//    if(x==y && y==z)
//      printf("All the numbers are same.");

//    return 0;
//  }