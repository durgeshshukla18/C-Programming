// #include<stdio.h>
// int main()
// {
//   int x;
//   printf("Enter a number:");
//   scanf("%d",&x);

//   if(x>99 && x<1000)
//     printf("Number is of 3 digits ");
//   else
//     printf("Number is not of 3 digits");
  

//   return 0;
// }