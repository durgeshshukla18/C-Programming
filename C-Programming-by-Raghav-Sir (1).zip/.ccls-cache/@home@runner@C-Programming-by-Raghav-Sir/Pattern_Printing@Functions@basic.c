// #include<stdio.h>
// void greet(){
//   printf("Hello PWIOI\n");
// }
// int main(){
//   greet();
//   greet();
//   greet();
// }