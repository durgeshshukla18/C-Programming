// #include<stdio.h>
// int add(int x, int y){
//   return x+y;
// }
//  int main()
// {
//   int a,b;
//   printf("Enter the value of a and b: ");
//   scanf(" %d %d",&a,&b);
//   int sum=add(a,b);
//   printf("The sum of a and b is %d",sum);
//   return 0;
// }
