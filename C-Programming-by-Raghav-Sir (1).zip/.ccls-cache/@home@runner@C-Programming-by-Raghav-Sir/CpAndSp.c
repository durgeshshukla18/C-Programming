// #include<stdio.h>
// int main()
// {
//   int x,y;
//   printf("Enter the CP:");
//   scanf("%d",&x);
//   printf("Enter the SP:");
//   scanf("%d",&y);

//   if(x>y)
//     printf("Loss");
//   if(x<y)
//     printf("Profit");
//   if(x==y)
//     printf("No Profit No Loss");

//   return 0;
// }