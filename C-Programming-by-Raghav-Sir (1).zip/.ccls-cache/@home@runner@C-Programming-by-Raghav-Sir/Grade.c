// #include<stdio.h>
//  int main()
//  {
//    int g;
//    printf("Enter the marks(0-100):");
//    scanf("%d",&g);
   

//    if(g>=81 && g<=100)
//      printf("Very Good.");
//    if(g>=61 && g<=80)
//      printf("Good");
//    if(g>=41 && g<=60)
//      printf("Average");
//    if(g<=40)
//      printf("Fail");

//    return 0;
//  }